# Claude / other AI handoff — MoneyMap v0.4

Continue the existing MoneyMap app. Read `README.md`, `PRODUCT_SPEC.md`, `USER_STORIES.json`, `CHANGELOG.md` and `TESTING.md`, then inspect `app.js`, `index.html`, `styles.css`, `manifest.webmanifest` and `sw.js`.

## Product direction
Friendly, non-technical, phone-first personal finance app. Keep the everyday interface warm, simple and touch-friendly. The product should help the user meet responsibilities, save and invest consistently, and enjoy life without guilt. Prefer cash-flow buckets and plain language over accounting terminology.

## Confirmed money rules
- Emergency savings are protected and excluded from everyday spending room. Moving money out requires explicit emergency override.
- Wants has a monthly ceiling; unused wants allowance rolls forward.
- Card purchase is recorded as an expense immediately and increases card liability.
- Card bill payment clears liability and reduces cash; it is not a second expense.
- Own-account transfers are neither income nor expense.
- Needs, debt, cash buffer and future commitments are reserved before discretionary spending.
- Investment contributions are tracked separately from ordinary expenses and market returns.
- Credit card is a payment method, not extra income. Reserve the purchase amount and pay the full statement by the due date. Never revolve debt to earn cashback.

## v0.4 implementation
- Added a dedicated Monthly Checkpoint tab with recurring and one-time items grouped by needs, debt/cards, emergency savings, investments, future goals, lifestyle and cash buffer.
- Items track target, due date, priority, account/card details, actual linked progress, remaining amount and status.
- Supports partial progress and linking existing transactions without duplicating entries.
- Checkpoint actions create the appropriate ledger item: expenses, card-liability settlements, own-account transfers or separate investment-contribution records.
- Added a current-month cash-flow estimate from configured recurring paydays and dated plan items. Expected income is labelled as an estimate and is not counted in safe-to-spend. Overdue unpaid commitments appear as due now.
- Added manual month close, local snapshots, reopen and optional carry-forward of unfinished items.
- Cash-buffer progress uses liquid accounts only, not emergency or future accounts.
- Existing localStorage key remains `moneymap_v2`. New additive arrays are `monthlyCheckpoints` and `monthSnapshots`; existing v0.3 browser data should remain compatible.
- Service-worker cache is `moneymap-v4`.

## Important implementation details
- Inspect the checkpoint code in `app.js`: `checkpointItems`, `checkpointActual`, `checkpointStatus`, `checkpointForecast`, `checkpointPage`, `addCheckpointItem`, `recordCheckpointProgress`, `linkCheckpointActivity`, `closeCheckpoint` and `reopenCheckpoint`.
- Transaction IDs are linked to checkpoint items. Deleting a transaction must reverse its balance effect and remove the checkpoint link.
- Investment contributions reduce the selected liquid account and create `investment_contribution` transactions; they must not be counted as ordinary expenses. A new contribution marks a holding's current value as needing an update; do not assume the investment value increased by the contribution amount.
- Month snapshots preserve account kind so the cash-buffer check does not accidentally include emergency/future accounts.
- Monthly templates copy into a new month. Unfinished one-time items carry forward only after the user confirms during month close.

## Known limitations
- No bank sync, payment execution, auto-posted salary, payday reminders or cloud database.
- Cash-flow projection is a current-month estimate, not a guaranteed day-by-day bank balance forecast. It uses user-entered dates and amounts.
- Card statement balance, unbilled purchases and due-date reminders are not fully reconciled.
- Investment contributions are manual; XIRR and benchmark comparison are not implemented.
- Local browser storage is not an encrypted vault. Users should export private JSON backups regularly.
- Desktop Chrome and real-device iPhone Safari acceptance testing are still required using a copy of the user's own backup.

## Deployment
- Public source repository: `https://github.com/anuragnarok/moneymap`.
- Live GitHub Pages URL: `https://anuragnarok.github.io/moneymap/`.
- Upload `MoneyMap_v0.4_GitHub_upload.zip` to the repository root to trigger deployment. The workflow now prioritises v0.4 over v0.3 and v0.2.
- Until that ZIP is uploaded and its Actions run succeeds, the live site remains on v0.3.
- Public repo/website must contain app source and generic documentation only. Never commit personal financial values, transaction data, account balances, credentials or JSON backups.

## Next priorities
1. Upload and deploy v0.4, then verify the live app.
2. Test v0.3 JSON backup migration on desktop Chrome and iPhone Safari.
3. Reconcile statement balance, unbilled card purchases and card due dates.
4. Add multi-month cash-flow scenarios and optional reminders only with explicit user opt-in.
5. Add dated investment contributions, XIRR and benchmark comparison.
6. Continue testing wants rollover and ledger edit/delete reversals.
