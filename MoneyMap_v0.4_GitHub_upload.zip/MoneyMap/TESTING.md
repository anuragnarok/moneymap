# MoneyMap v0.4 testing notes

The v0.4 JavaScript passed `node --check`. A Node VM smoke-test harness exercised the core checkpoint flows against a v0.3-shaped localStorage fixture.

Verified in the harness:
- Additive loading of `monthlyCheckpoints` and `monthSnapshots` while preserving the existing `moneymap_v2` storage key.
- Partial needs payment reduces the selected liquid account and links the resulting transaction to the checkpoint.
- Emergency-fund contribution is an own-account transfer, not an expense.
- Partial card payment reduces card outstanding and creates a `card_payment`, not a second expense.
- Investment contribution reduces cash and is recorded separately from expenses and valuation changes.
- Deleting an investment contribution restores cash and removes the linked checkpoint progress.
- Checkpoint view renders, month close saves a snapshot, and reopening leaves the snapshot intact.
- Current-month cash-flow estimate includes future expected paydays and dated commitments; expected inflows remain separate from safe-to-spend.

Still required before relying on it for real finances: test in desktop Chrome and iPhone Safari with a copy of the user's actual JSON backup; verify balances and PWA offline persistence. The automated harness is not a substitute for a real-device acceptance test.
