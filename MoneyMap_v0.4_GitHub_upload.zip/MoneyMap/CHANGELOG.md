# Changelog

## v0.3 — 13 November 2026
- Added separate recurring income sources for job salary and freelance work.
- Added expected pay-day fields (default suggestions: day 1 and day 13; user can edit them).
- Dashboard and More page show expected monthly income from configured recurring sources.
- One-time income is explicitly handled through Add money and is not counted as recurring income.
- Kept the existing localStorage key and merged new settings defaults so v0.2 data remains compatible.
- Updated PWA cache name so installed devices fetch the new app files.
- Updated Claude handoff, product spec and README.

# Changelog

## v0.2 — 12 November 2026
- Replaced technical-looking prototype with a friendly, phone-first money companion.
- Added onboarding for income, needs, wants and starting account balances.
- Added protected emergency savings and confirmation before moving money out.
- Added income, spending, card purchases and card bill settlement.
- Added account-to-account transfers; transfers are not treated as income or spending.
- Added wants rollover calculation across calendar months.
- Added future savings goals and a plain-language affordability check.
- Added Axis Bank Flipkart card defaults based on current public Axis product information.
- Split cashback estimates into other online, café/restaurant and other offline purchases; all default to 1% unless a named partner category applies.
- Café spend is estimated at 1% as other eligible spend, not guaranteed; preferred merchant list/MCC must be verified.
- Added iPhone touch icon PNGs, PWA manifest and offline service worker.
- Kept storage local to the browser; no external database, analytics, bank connection or cloud sync.
- Added Claude handoff, updated product spec, README and user stories.

## Known unfinished items
- Automated card statement reconciliation, due date reminders and cashback cap tracking.
- Fully tested ledger edit/delete and month-close rollover edge cases.
- 3–12 month cash-flow scenarios and EMI total-cost comparison.
- Investment XIRR and benchmark comparison.
- Free HTTPS hosting deployment and real-device iPhone Safari testing.


## v0.4 — Monthly Financial Checkpoint
- Added a dedicated Checkpoint tab for monthly planning and actual progress tracking.
- Creates a monthly checklist from existing needs, debt, wants, cash-buffer, card and future-goal settings.
- Supports custom recurring and one-time checkpoints with category, target, due date, priority and account details.
- Supports partial payments and contributions, and links them to the existing transaction ledger.
- Adds progress recording for bills/debt/lifestyle, card bill payments, emergency/future-goal transfers and investment contributions.
- Allows linking existing eligible activity without creating duplicate transactions.
- Adds month navigation, a month-end snapshot and manual close/reopen with optional carry-forward of unfinished recurring items.
- Keeps existing localStorage key and adds new data fields without resetting v0.3 data.
- Bumps service-worker cache to v4.

## v0.4 known limitations
- Cash-flow projection is a simple current-month estimate based on expected income days and plan-item due dates; it is not a bank feed or a guaranteed balance forecast. Expected income is not counted as available-to-spend.
- Investment contribution records are manual and update the simple holdings snapshot; they do not verify an actual broker debit or calculate XIRR.
- Existing transactions can be linked manually; automatic matching is not enabled to avoid incorrect associations.
- Month-end snapshots are local-only and should be included in regular JSON backups.
