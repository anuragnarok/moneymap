# Claude / other AI handoff — MoneyMap v0.3

Continue the existing MoneyMap app. Read `README.md`, `PRODUCT_SPEC.md`, `USER_STORIES.json`, `FINANCIAL_PLAN_NOV2026_JAN2027.md` (private context; keep out of public GitHub), then inspect `app.js`, `index.html`, `styles.css`, `manifest.webmanifest` and `sw.js`.

## Product direction
Friendly, non-technical, phone-first personal finance app. Keep the everyday interface warm, simple and touch-friendly. The user found the prior setup confusing; explain concepts in ordinary language and prefer cash-flow buckets over accounting terminology.

## Confirmed money rules
- Emergency savings are protected and excluded from everyday spending room. Moving money out requires explicit emergency override.
- Wants has a monthly ceiling; unused wants allowance rolls forward.
- Card purchase is recorded as an expense immediately and increases card liability.
- Card bill payment clears liability and reduces cash; it is not a second expense.
- Own-account transfers are neither income nor expense.
- Needs, debt, cash buffer and future commitments are reserved before discretionary spending.
- Credit card is a payment method, not extra income. Reserve the purchase amount and pay the full statement by the due date. Never revolve debt to earn cashback.

## v0.3 implementation
- Added recurring income settings: job salary amount + expected day, freelance amount + expected day.
- Expected monthly income is the sum of configured regular sources.
- The More page shows each source and its expected pay day.
- One-time payments (bonus, project payment, fitness client) should be entered using Add money when received; do not treat them as recurring income.
- Existing localStorage key remains `moneymap_v2`; v0.2 user data should remain compatible.
- Service-worker cache renamed to `moneymap-v3` to refresh installed app assets.

## Known limitation of the new income schedule
The app stores and displays amounts and expected pay days, but it does not automatically create income transactions, send payday reminders, or forecast exact cash balances by date. Build that only after adding a reliable forecast model and explicit opt-in reminders.

## Axis Bank Flipkart credit card
- User says non-RuPay; exact Visa/Mastercard network unknown.
- Headline rates previously checked: Flipkart 5%, Myntra 7.5%, Cleartrip 5%, preferred merchants 4%, other eligible spend 1%; quarterly caps apply to selected categories.
- Cafés/restaurants are not a default accelerated category; estimate 1% as other eligible spend, not guaranteed. Merchant ID/MCC, exclusions and current terms decide eligibility.
- Do not encourage extra spending for cashback. Pay full statement by due date.
- Re-check current Axis terms before implementing exact rewards, exclusions or caps.

## Privacy / deployment
- Public source repository: `https://github.com/anuragnarok/moneymap`.
- Live GitHub Pages URL: `https://anuragnarok.github.io/moneymap/`. Prior Actions build and deploy jobs succeeded. The Pages workflow was updated to accept `MoneyMap_v0.3_GitHub_upload.zip` at the repository root; upload that exact file name to publish v0.3. Until the new ZIP is uploaded, the public site still serves the earlier v0.2 bundle. The workflow update itself successfully built the existing fallback bundle; the deploy job was still queued at last check.
- The public repo/website must contain app source and generic documentation only. Never commit the private finance note, account balances, transactions, bank/card credentials or JSON backup.
- App data is stored in browser localStorage on the current device. No cloud sync or remote database. Export JSON backups regularly.
- Static PWA hosting is enough; Railway/backend not needed.

## First priority / backlog
1. Test ledger balance and delete reversals for income, cash expense, card purchase, card payment and transfers.
2. Add real cash-flow forecast using actual opening balances, income arrival dates, bills and trip commitments.
3. Add recurring income/bill reminders only with explicit user opt-in.
4. Separate statement balance, unbilled card purchases and total outstanding; add due-date reminders.
5. Reconcile cashback quarterly caps and actual statement cashback.
6. Improve wants rollover when budgets change and months are skipped.
7. Add dated investment contributions and XIRR.

## Important
Do not hardcode the user's personal finance values into source code or public files. The private financial plan is in `FINANCIAL_PLAN_NOV2026_JAN2027.md` inside the private Claude handoff ZIP only. Do not upload that file to the public GitHub repository.
