# MoneyMap — Product specification (v0.3)

## Product promise
A calm, friendly money companion that helps the user enjoy wants without accidentally spending money already promised to needs, debt, emergencies or future plans.

## Audience and tone
- Individual user in India; INR-first.
- Mobile-first, especially iPhone.
- Friendly, non-technical language. Avoid accounting jargon in the everyday UI.
- The app should answer questions such as "Can I have an Americano today?", "Can I buy this phone?", and "What happens if I book the flight now?"

## Agreed money rules
1. Emergency savings are protected and excluded from normal discretionary spending.
2. Wants has a monthly ceiling. Unused allowance rolls over to future months.
3. A credit-card purchase is an expense at purchase time and increases card liability.
4. Paying the credit-card statement is a liability settlement / transfer, not another expense.
5. Moving money between the user's own accounts is a transfer, not income or expense.
6. Needs and future commitments are reserved before discretionary spending.

## User experience principles
- Dashboard first; show "Safe spending room" in plain language.
- Primary actions: Add spending, Add money, Check a want, Move money.
- Use friendly category names and simple explanations.
- Touch-friendly buttons, responsive layout, no dense tables in the everyday flow.
- No account numbers, card numbers or bank credentials stored.
- Show why a purchase looks affordable or why waiting is safer.

## Account model
- Everyday money / salary account.
- Emergency savings (protected).
- Future plans / sinking-fund account.
- Additional user-defined accounts.
- Transfers between accounts adjust balances only.

## Spending room model
Safe spending room is the lower of:
- Remaining wants allowance (monthly wants budget + rollover − wants spent).
- Everyday account balance less: cash buffer, unpaid card balance, remaining planned needs, remaining planned debt payments, and future-plan contributions not yet transferred.

This is a conservative estimate. The UI must show assumptions and must not imply a guaranteed financial recommendation. Do not count emergency savings as available.

## Axis Bank Flipkart credit card setup
Preconfigured card profile, editable by user:
- Flipkart 5%, Cleartrip 5%, Myntra 7.5% (each headline merchant cap ₹4,000 per statement quarter).
- Preferred merchants 4% (merchant list may change).
- Other eligible merchants 1%.
- Other online purchases, café/restaurant payments and other offline purchases are shown as separate choices but provisionally estimated at 1% as other eligible spend unless exact merchant is on the current preferred list. Eligibility depends on merchant ID/MCC and current exclusions.
- Current Axis product page reports ₹500 annual fee from second year onward, waiver above ₹3.5 lakh eligible annual spends, and finance charges of 3.75% monthly (55.55% p.a.).
- Current Axis product page notes terms updated effective 28 August 2026. All rates must be confirmed against the latest cardmember agreement and user's actual statement.
- Never suggest carrying card debt to earn cashback.

## Data and privacy
- v0.2 stores data locally in browser storage.
- No external database or account aggregation is used. A remote database is unnecessary for a single-device planner and would add a privacy surface.
- User can export/import JSON backups. Backups are sensitive.
- Future sync must be optional, encrypted, and require explicit opt-in.

## v0.3 delivered in this bundle
- Separate recurring job salary and freelance income amounts and expected pay days.
- Expected monthly income totals the configured recurring sources.
- One-time income remains a manually recorded transaction and is not silently annualized or treated as recurring.
- Existing v0.2 local browser data is retained through settings defaults and compatibility fallback.

## v0.2 delivered in this bundle
- Mobile-first, friendly interface.
- Setup modal.
- Dashboard and safe spending estimate.
- Manual income/expense and card purchase recording.
- Card outstanding and bill settlement.
- Account transfer flow.
- Monthly wants rollover.
- Future goal planner.
- Axis Flipkart reward estimate.
- Investment value snapshot.
- JSON backup/restore.
- PWA manifest and offline cache.

## Backlog

### P0 — financial correctness
- [ ] Unit-tested transaction ledger; support editing and safely reversing all transaction types.
- [ ] Transfer between any accounts with validation and correct deletion reversal.
- [ ] Correct month-by-month rollover including skipped months, overspend carry-forward and budget changes.
- [ ] Reconcile account balances from opening balances and ledger entries.
- [ ] Separate current statement balance, unbilled card spends and total outstanding.
- [ ] Track statement generation date, payment due date, minimum due and full amount due.
- [ ] Verify current Axis cashback terms, excluded MCCs, merchant list and caps; mark unknown merchant rewards as unverified.
- [ ] Cashback quarter cap tracker and actual cashback reconciliation.

### P1 — planning
- [ ] Forecast actual cash arrival dates for recurring salary and freelance income (current v0.3 only stores and displays expected pay days; it does not auto-post income).
- [ ] Month-by-month forecast for 3–12 months.
- [ ] Compare buy now, delay, cash, card-paid-in-full and EMI options.
- [ ] Add recurring bills, salary and debt payments.
- [ ] Add flight/trip/gadget savings scenarios and target-date warnings.
- [ ] Build a gentle daily "Can I spend this?" decision flow.

### P1 — investments
- [ ] Record each lump-sum contribution with date, scheme, units and NAV.
- [ ] Calculate XIRR for irregular contributions.
- [ ] Compare funds with suitable benchmarks and category peers.
- [ ] Show portfolio allocation and concentration; no automated buy/sell recommendations.

### P2 — reliability and convenience
- [ ] Test PWA install and local data persistence on iPhone Safari.
- [ ] Add CSV export/import and better backup validation.
- [ ] Add optional encrypted multi-device sync only if the user requests it.
- [ ] Add privacy lock / Face ID through supported platform capabilities where feasible.
- [ ] Accessibility audit: text scaling, contrast, VoiceOver labels and keyboard navigation.

## Hosting decision
- Static PWA hosting is sufficient for v0.2. Recommended free option: Cloudflare Pages or GitHub Pages.
- Railway subscription is not required for this no-backend version.
- Deployment has not been performed because no hosting account/repository authorization is available in this workflow. The ZIP is ready to deploy.

## Acceptance criteria
- A user can use the main flows from a phone without technical knowledge.
- Emergency savings never appear as normal spending room.
- Card purchases and card payments are never double-counted.
- Account transfers are not counted as spending.
- Unknown card reward eligibility is not presented as guaranteed.
- Data remains local by default and can be exported/restored.
