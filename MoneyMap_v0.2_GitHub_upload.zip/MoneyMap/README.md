# MoneyMap v0.2 — friendly personal money planner

A mobile-first, local-first Progressive Web App (PWA). Designed for everyday use on an iPhone or Android phone. It uses plain language, large tap targets and simple money checks.

## Open it
- Open `index.html` in a browser for a quick local preview.
- For offline support and iPhone home-screen installation, host the folder on an HTTPS static host.
- On iPhone: open the hosted URL in Safari → Share → Add to Home Screen.
- On Android: open in Chrome → menu → Install app / Add to Home Screen.

## Free hosting recommendation
Use GitHub Pages or Cloudflare Pages for this static app. No server is required for the current version. Railway is not necessary unless a future version adds a backend/API. This package is deployment-ready but is not published to a live public URL; the user's hosting account/repository must be authorized to publish it.

### GitHub Pages (free)
1. Create a new GitHub repository for MoneyMap.
2. Upload the *contents* of this MoneyMap folder to the repository root (index.html should be at the root).
3. In the repository, open Settings → Pages.
4. Choose Deploy from a branch, select the main branch and root folder, then Save.
5. After GitHub gives you the Pages URL, open it in iPhone Safari → Share → Add to Home Screen.

### Cloudflare Pages (free static hosting)
1. Create a Pages project and connect a GitHub repository, or use Direct Upload.
2. For a plain static site, use no build command and set the output directory to the folder containing index.html.
3. Open the HTTPS URL in iPhone Safari → Share → Add to Home Screen.

A GitHub connection can help publish and maintain the project. No private finance data should be committed to the repository.

## Storage and privacy
- App data stays in the current browser on the current device using local browser storage.
- No external database, analytics, bank connector, or cloud sync is used.
- This is intentional: a remote database would create a new privacy surface and is not required for a single-device personal planner.
- Use **More → Download my backup** regularly. Restore from the JSON backup on a new device.
- Exported finance backups are sensitive. Do not share them with an AI or third party unless you intend to.
- Clearing Safari website data can erase app data. Keep a backup before clearing browser history/site data or changing phones.

## Financial logic
1. Emergency savings are protected and excluded from normal spending room.
2. Wants has a monthly ceiling and unused allowance rolls forward.
3. Card purchases are recorded as expenses at purchase time and increase card outstanding.
4. Card bill payments reduce bank cash and card outstanding; they are not recorded as a second expense.
5. Transfers between a user's own accounts do not count as income or expense.
6. The spending check reserves the cash buffer, card outstanding, remaining needs/debt budget and future-goal contributions, then checks the remaining wants allowance.

## Axis Bank Flipkart Credit Card profile
Headline rates currently shown on Axis Bank's official product page:
- Flipkart: 5% cashback, quarterly cap ₹4,000.
- Cleartrip: 5%, quarterly cap ₹4,000.
- Myntra: 7.5%, quarterly cap ₹4,000.
- Preferred merchants: 4%, list can change.
- Other eligible spends: 1%.
- Annual fee shown: ₹500 from year two; fee waiver shown above ₹3.5 lakh eligible annual spends.
- Finance charges shown: 3.75% per month (published as 55.55% p.a. on the product page).

Café / restaurant payments:
- Not a dedicated accelerated cashback category by default.
- App estimates 1% as an "other eligible merchant" spend, subject to merchant ID/MCC and exclusions.
- Do not assume 4% unless the exact merchant is on Axis's current preferred-merchant list.
- The official Axis page says card terms were updated effective 28 August 2026. Verify the latest cardmember agreement and the actual statement cashback before relying on the estimate.
- EMI transactions and listed excluded merchant categories may not earn cashback. The exact exclusions and caps should be rechecked against the latest terms before v0.3 implements full cashback reconciliation.

Official source: https://www.axis.bank.in/cards/credit-card/flipkart-axisbank-credit-card

## v0.2 included
- Friendly mobile-first dashboard and simple wording.
- First-run setup for monthly income, needs, wants and account balances.
- Three account purposes: everyday, emergency, future plans.
- Manual income and expense tracking.
- Credit-card purchase capture with Axis card reward estimate.
- Card bill payment that clears liability without double-counting spending.
- Account-to-account transfer.
- Wants rollover by month (simple month-on-month calculation).
- Future goal planner with monthly saving target.
- Purchase affordability check.
- Investment value snapshot.
- Local backup and restore.
- PWA manifest and offline service worker.

## Known limitations / next work
- Card statement generation and due-date reminders are not yet automated.
- Cashback is an estimate; no live bank statement or merchant MCC lookup.
- Preferred merchant list and exclusions should be checked against the current cardmember terms.
- Purchase simulator is a conservative planning check, not a full day-by-day cash-flow forecast.
- EMI calculator is a future enhancement; current app should not be treated as a full loan quote.
- Investment snapshot does not calculate XIRR, benchmark-relative returns or tax.
- Wants rollover needs month-close testing and explicit handling for months with no app use.
- No encrypted database, login, cloud sync or automatic cross-device backup.

## Recommended next milestone
1. Add unit-tested ledger engine with reversible edits/deletes and proper transfer handling.
2. Add statement cycles, due dates, payment reminders and cashback cap tracking.
3. Add monthly cash-flow forecast and buy-now / delay / cash / card / EMI comparisons.
4. Add dated investment cash flows and XIRR.
5. Test on iPhone Safari, install to home screen, and validate persistence after closing/reopening.
