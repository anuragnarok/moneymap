# Claude / other AI handoff — MoneyMap v0.2

Continue the existing MoneyMap app. Read `README.md`, `PRODUCT_SPEC.md`, `USER_STORIES.json`, then inspect `app.js`, `index.html`, `styles.css`, `manifest.webmanifest` and `sw.js`.

## Product direction
Friendly, non-technical, phone-first personal finance app. Keep the everyday interface warm, simple and touch-friendly. Do not turn it into an accounting dashboard.

## Confirmed rules
- Emergency savings are protected and excluded from everyday spending room.
- Wants has a monthly ceiling; unused allowance rolls forward.
- Card purchase is recorded as an expense immediately and adds to card liability.
- Card bill payment clears the liability and reduces bank cash, never a second expense.
- Own-account transfers are not income or expense.
- Needs, debt, cash buffer and future commitments are reserved before wants.

## Axis Bank Flipkart card
- Headline rates from Axis product page: Flipkart 5%, Myntra 7.5%, Cleartrip 5%, preferred merchants 4%, other eligible spend 1%.
- ₹4,000 per statement-quarter caps are shown for Flipkart, Myntra and Cleartrip.
- Other online purchases and café/restaurant are shown separately in the UI but both use a provisional 1% estimate as other eligible spend; exact eligibility depends on merchant ID/MCC and latest exclusions. Do not promise rewards.
- Product page currently reports 3.75% monthly finance charge, ₹500 annual fee from year two and annual fee waiver at eligible annual spend above ₹3.5 lakh.
- Axis page says terms updated effective 28 Aug 2026. Re-check latest cardmember agreement before coding exact reward rules.
- Never recommend revolving card debt to earn cashback.

## Privacy and hosting
- v0.2 uses browser local storage. No external DB, bank connector, analytics or cloud sync.
- Keep local-first. Optional encrypted sync only with explicit user opt-in.
- Static PWA can be hosted free on Cloudflare Pages or GitHub Pages. Railway is unnecessary unless backend functionality is added.
- Do not claim it is hosted. Deployment has not been done; no hosting account/repository authorization was provided.
- On iPhone, deploy to HTTPS and use Safari Share → Add to Home Screen. Test offline and persistence.

## First priority
Audit `app.js` for correctness before adding features. Known areas to improve:
1. Unit-test ledger balances and reverse/delete flows for income, cash expense, card purchase, card payment and account transfer.
2. Make monthly rollover robust across skipped months and budget changes.
3. Reconcile account balances from opening balances + transactions.
4. Separate statement balance from unbilled card purchases and full outstanding.
5. Implement actual due dates, payment reminders, reward quarter caps and current issuer exclusions.
6. Build 3–12 month cash-flow forecasts and buy-now/delay/cash/card/EMI comparisons.
7. Add investment contribution dates and XIRR.

## Important
Do not put real financial data, bank credentials, card numbers or personal exports in source code or tests. Use synthetic test data. The ZIP contains source and product docs only, not private account transactions.
